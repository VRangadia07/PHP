
<?php 

// $db['db_host'] = "localhost";
// $db['db_user'] = "root";
// $db['db_pass'] = "";
// $db['db_name'] = "cms";

// foreach($db as $key => $value){

//     define(strtoupper($key), $value);
// }

// $connection = mysqli_connect('DB_HOST', 'DB_USER', 'DB_PASS', 'DB_NAME');

// if ($connection) {
//    // echo "we are connected.";
// }
?>

<?php
    // include 'admin/function.php';

$connection = mysqli_connect('localhost', 'root', '','cms1');

if ($connection) {

    //echo "we are connect";
    
}
//query("SET NAMES utf8"); 
// $query = "SET NAMES utf-8 ";
// mysqli_query($connection, $query);


?>