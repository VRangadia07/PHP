<footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Start_CMS 2020</p>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="/cms/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="/cms/js/bootstrap.min.js"></script>

</body>

</html>