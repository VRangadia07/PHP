<?php 

const _REGISTER = "रजिस्टर";
const _USERNAME = "अपना उपयोगकर्ता नाम दर्ज करें";
const _EMAIL = "अपना ईमेल दर्ज करें";
const _PASSWORD = "अपना पासवर्ड यहां दर्ज करें";