<?php 

const _REGISTER = "રજિસ્ટર";
const _USERNAME = "તમારું વપરાશકર્તા નામ દાખલ કરો";
const _EMAIL = "તમારું ઈમેલ એડ્રેસ લખો";
const _PASSWORD = "તમારો પાસવર્ડ નાખો";