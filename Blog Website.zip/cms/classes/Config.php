<?php


class Config {


    const SMTP_HOST = 'smtp.mailtrap.io';


    const SMTP_PORT = 2525;

    const SMTP_USER = 'e7d2d34a0e455c';

    const SMTP_PASSWORD = '846458b1ad4ac7';



}
